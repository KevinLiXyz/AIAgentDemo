"""
测试脚本 - 验证RAG系统和聊天机器人功能
Test Script for RAG System Validation
"""

import os
import sys
from app.rag import RAGRetriever
from app.chatbot import GovernmentChatbot


def test_rag_initialization():
    """测试RAG系统初始化"""
    print("\n" + "="*70)
    print("测试 1: RAG系统初始化")
    print("="*70)
    
    try:
        rag = RAGRetriever()
        rag.initialize(force_rebuild=True)
        print("✅ RAG系统初始化成功")
        return rag
    except Exception as e:
        print(f"❌ RAG系统初始化失败: {e}")
        return None


def test_retrieval(rag: RAGRetriever):
    """测试文档检索功能"""
    print("\n" + "="*70)
    print("测试 2: 文档检索功能")
    print("="*70)
    
    test_queries = [
        "考试时间是多久?",
        "需要掌握哪些技术?",
        "有哪些加分项?"
    ]
    
    try:
        for i, query in enumerate(test_queries, 1):
            print(f"\n查询 {i}: {query}")
            docs = rag.retrieve(query)
            print(f"  检索到 {len(docs)} 个相关文档")
            if docs:
                print(f"  最相关片段: {docs[0].page_content[:150]}...")
        
        print("\n✅ 文档检索测试通过")
        return True
    except Exception as e:
        print(f"❌ 文档检索测试失败: {e}")
        return False


def test_chatbot(rag: RAGRetriever):
    """测试聊天机器人功能"""
    print("\n" + "="*70)
    print("测试 3: 聊天机器人功能")
    print("="*70)
    
    # 检查API Key
    if not os.getenv("OPENAI_API_KEY"):
        print("⚠️  警告: OPENAI_API_KEY未设置,跳过聊天机器人测试")
        print("   请在.env文件中设置API Key后重新测试")
        return False
    
    try:
        chatbot = GovernmentChatbot(rag)
        
        test_questions = [
            "考试包括哪些科目?",
            "需要多长时间考完?",
            "Python和Java都要会吗?"
        ]
        
        for i, question in enumerate(test_questions, 1):
            print(f"\n问题 {i}: {question}")
            response = chatbot.chat(question)
            print(f"回答: {response['answer'][:200]}...")
        
        print("\n✅ 聊天机器人测试通过")
        return True
    except Exception as e:
        print(f"❌ 聊天机器人测试失败: {e}")
        return False


def run_all_tests():
    """运行所有测试"""
    print("\n" + "="*70)
    print("🧪 开始运行测试套件")
    print("="*70)
    
    results = {
        "RAG初始化": False,
        "文档检索": False,
        "聊天机器人": False
    }
    
    # 测试1: RAG初始化
    rag = test_rag_initialization()
    results["RAG初始化"] = rag is not None
    
    if not rag:
        print("\n❌ RAG初始化失败,终止后续测试")
        print_summary(results)
        return False
    
    # 测试2: 文档检索
    results["文档检索"] = test_retrieval(rag)
    
    # 测试3: 聊天机器人
    results["聊天机器人"] = test_chatbot(rag)
    
    # 打印测试摘要
    print_summary(results)
    
    return all(results.values())


def print_summary(results: dict):
    """打印测试摘要"""
    print("\n" + "="*70)
    print("📊 测试摘要")
    print("="*70)
    
    for test_name, passed in results.items():
        status = "✅ 通过" if passed else "❌ 失败"
        print(f"  {test_name}: {status}")
    
    total = len(results)
    passed = sum(results.values())
    
    print(f"\n总计: {passed}/{total} 测试通过")
    
    if passed == total:
        print("\n🎉 所有测试通过! 系统运行正常.")
    else:
        print("\n⚠️  部分测试失败,请检查配置和依赖.")


def main():
    """主测试函数"""
    try:
        success = run_all_tests()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n⚠️  测试被用户中断")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 测试过程中出现异常: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
