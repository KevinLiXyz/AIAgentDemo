"""
LLM 配置测试工具
测试不同的大语言模型配置
"""

import sys
import os

def test_openai():
    """测试 OpenAI"""
    print("\n" + "="*70)
    print("🧪 测试 1: OpenAI GPT")
    print("="*70)
    
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key:
        print("⚠️  未配置 OPENAI_API_KEY")
        return False
    
    try:
        from langchain_openai import ChatOpenAI
        
        print(f"  API Key: {api_key[:10]}...")
        llm = ChatOpenAI(
            model="gpt-3.5-turbo",
            temperature=0.7,
            openai_api_key=api_key
        )
        
        print("  ⏳ 测试调用...")
        response = llm.invoke("你好,请用一句话介绍自己")
        print(f"  ✅ 成功! 回答: {response.content[:50]}...")
        return True
        
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False


def test_ollama():
    """测试 Ollama"""
    print("\n" + "="*70)
    print("🧪 测试 2: Ollama 本地模型")
    print("="*70)
    
    try:
        from langchain_community.llms import Ollama
        import requests
        
        # 检查服务
        base_url = "http://localhost:11434"
        print(f"  服务地址: {base_url}")
        
        try:
            response = requests.get(base_url, timeout=2)
            print("  ✅ Ollama 服务正在运行")
        except:
            print("  ❌ Ollama 服务未启动")
            print("     请运行: ollama serve")
            return False
        
        # 检查模型
        model_name = os.getenv("OLLAMA_MODEL", "qwen2.5:7b")
        print(f"  模型: {model_name}")
        
        llm = Ollama(
            model=model_name,
            base_url=base_url,
            temperature=0.7
        )
        
        print("  ⏳ 测试调用 (可能需要10-30秒)...")
        response = llm.invoke("你好,请用一句话介绍自己")
        print(f"  ✅ 成功! 回答: {response[:50]}...")
        return True
        
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        print("\n  💡 确保:")
        print("     1. Ollama 已安装: https://ollama.ai")
        print("     2. 服务已启动: ollama serve")
        print("     3. 模型已下载: ollama pull qwen2.5:7b")
        return False


def test_fake():
    """测试 Fake LLM"""
    print("\n" + "="*70)
    print("🧪 测试 3: 测试模式 (FakeLLM)")
    print("="*70)
    
    try:
        from langchain_community.llms.fake import FakeListLLM
        
        responses = ["这是一个测试回答"]
        llm = FakeListLLM(responses=responses)
        
        print("  ⏳ 测试调用...")
        response = llm.invoke("测试")
        print(f"  ✅ 成功! 回答: {response}")
        print("  ⚠️  注意: 这只是固定回答,不是真实智能")
        return True
        
    except Exception as e:
        print(f"  ❌ 失败: {e}")
        return False


def check_ollama_models():
    """检查 Ollama 已下载的模型"""
    print("\n" + "="*70)
    print("📦 检查 Ollama 模型")
    print("="*70)
    
    try:
        import subprocess
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if result.returncode == 0:
            print(result.stdout)
            return True
        else:
            print("  ⚠️  无法列出模型")
            return False
            
    except FileNotFoundError:
        print("  ⚠️  Ollama 未安装")
        print("  安装: https://ollama.ai/download")
        return False
    except Exception as e:
        print(f"  ⚠️  {e}")
        return False


def suggest_configuration():
    """建议配置"""
    print("\n" + "="*70)
    print("💡 配置建议")
    print("="*70)
    
    has_openai = bool(os.getenv("OPENAI_API_KEY"))
    
    print("\n当前环境:")
    print(f"  OpenAI Key: {'✅ 已配置' if has_openai else '❌ 未配置'}")
    
    # 检查 Ollama
    try:
        import requests
        response = requests.get("http://localhost:11434", timeout=2)
        has_ollama = True
    except:
        has_ollama = False
    
    print(f"  Ollama 服务: {'✅ 运行中' if has_ollama else '❌ 未运行'}")
    
    print("\n推荐配置 (.env 文件):")
    
    if has_openai and has_ollama:
        print("""
# 智能切换模式 (推荐)
LLM_TYPE=auto
OPENAI_API_KEY=sk-xxx
OLLAMA_MODEL=qwen2.5:7b

这样配置会优先使用 OpenAI,出问题时降级到 Ollama
        """)
    elif has_openai:
        print("""
# OpenAI 模式
LLM_TYPE=openai
OPENAI_API_KEY=sk-xxx
        """)
    elif has_ollama:
        print("""
# Ollama 本地模式 (免费)
LLM_TYPE=ollama
OLLAMA_MODEL=qwen2.5:7b
        """)
    else:
        print("""
# 您需要配置其中一种:

方式1: OpenAI (推荐,需要API Key)
  OPENAI_API_KEY=sk-xxx

方式2: Ollama (免费,需要安装)
  1. 安装: https://ollama.ai/download
  2. 下载模型: ollama pull qwen2.5:7b
  3. 配置: LLM_TYPE=ollama

方式3: 测试模式 (仅用于测试)
  LLM_TYPE=fake
        """)


def main():
    """主函数"""
    print("\n" + "="*70)
    print("🔍 LLM 配置测试工具")
    print("="*70)
    print("\n这个工具将测试各种 LLM 配置是否可用")
    
    # 检查 Ollama 模型
    check_ollama_models()
    
    # 测试各种 LLM
    results = {
        "OpenAI": test_openai(),
        "Ollama": test_ollama(),
        "FakeLLM": test_fake()
    }
    
    # 总结
    print("\n" + "="*70)
    print("📊 测试结果总结")
    print("="*70)
    
    for name, success in results.items():
        status = "✅ 可用" if success else "❌ 不可用"
        print(f"  {name:15} {status}")
    
    available_count = sum(results.values())
    print(f"\n  可用方式: {available_count}/3")
    
    # 建议配置
    suggest_configuration()
    
    # 下一步
    print("\n" + "="*70)
    print("📝 下一步操作")
    print("="*70)
    
    if any(results.values()):
        print("\n✅ 至少有一种 LLM 可用!")
        print("\n现在可以运行:")
        print("  python main.py        # 启动智能客服")
        print("  python demo_simple.py # 测试RAG检索")
    else:
        print("\n❌ 没有可用的 LLM")
        print("\n请选择一种方式:")
        print("  1. 配置 OpenAI API Key")
        print("  2. 安装 Ollama (免费)")
        print("  3. 使用测试模式 (LLM_TYPE=fake)")
        print("\n详细指南:")
        print("  notepad OLLAMA_GUIDE.md")
    
    return 0 if any(results.values()) else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\n⚠️  已取消")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 发生错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
