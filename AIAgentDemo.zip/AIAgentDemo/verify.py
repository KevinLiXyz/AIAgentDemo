"""
快速验证脚本 - 检查项目结构和导入
Quick validation script to check project structure
"""

import sys
import os

def check_structure():
    """检查项目结构"""
    print("="*70)
    print("🔍 检查项目结构")
    print("="*70)
    
    required_files = [
        "app/__init__.py",
        "app/config.py",
        "app/rag.py",
        "app/chatbot.py",
        "data/recruitment_knowledge.md",
        "main.py",
        "test.py",
        "requirements.txt",
        ".env.example"
    ]
    
    all_exist = True
    for file in required_files:
        exists = os.path.exists(file)
        status = "✅" if exists else "❌"
        print(f"{status} {file}")
        if not exists:
            all_exist = False
    
    return all_exist

def check_dependencies():
    """检查关键依赖是否可导入"""
    print("\n" + "="*70)
    print("📦 检查依赖包")
    print("="*70)
    
    dependencies = {
        "dotenv": "python-dotenv",
        "langchain": "langchain",
        "langchain_community": "langchain-community",
        "langchain_openai": "langchain-openai",
        "sentence_transformers": "sentence-transformers",
        "faiss": "faiss-cpu"
    }
    
    missing = []
    for module, package in dependencies.items():
        try:
            __import__(module)
            print(f"✅ {package}")
        except ImportError:
            print(f"❌ {package} (未安装)")
            missing.append(package)
    
    return len(missing) == 0, missing

def main():
    print("\n🚀 项目验证脚本\n")
    
    # 检查结构
    structure_ok = check_structure()
    
    # 检查依赖
    deps_ok, missing_deps = check_dependencies()
    
    # 总结
    print("\n" + "="*70)
    print("📊 验证结果")
    print("="*70)
    
    if structure_ok:
        print("✅ 项目结构完整")
    else:
        print("❌ 项目结构不完整,请检查缺失文件")
    
    if deps_ok:
        print("✅ 所有依赖已安装")
    else:
        print(f"❌ 缺少依赖: {', '.join(missing_deps)}")
        print("\n💡 安装命令:")
        print("   pip install -r requirements.txt")
    
    if structure_ok and deps_ok:
        print("\n🎉 验证通过! 项目已就绪.")
        print("\n📝 下一步:")
        print("   1. 复制 .env.example 为 .env")
        print("   2. 在 .env 中配置 OPENAI_API_KEY")
        print("   3. 运行: python main.py")
        return 0
    else:
        print("\n⚠️  请解决上述问题后再运行应用.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
