"""
简化演示脚本 - 仅展示RAG检索功能(无需OpenAI API)
Simplified demo showing RAG retrieval without requiring OpenAI API
"""

import os
import sys
from app.rag import RAGRetriever


def print_banner():
    """打印横幅"""
    print("""
╔══════════════════════════════════════════════════════════════╗
║                RAG检索系统演示                                  ║
║           (无需OpenAI API Key)                                ║
╚══════════════════════════════════════════════════════════════╝
    """)


def demo_retrieval():
    """演示文档检索功能"""
    print_banner()
    
    print("🔧 初始化RAG检索系统...\n")
    
    try:
        # 初始化RAG
        rag = RAGRetriever()
        rag.initialize(force_rebuild=True)
        
        print("\n" + "="*70)
        print("📝 演示查询")
        print("="*70)
        
        # 示例查询
        queries = [
            "考试时间是多长?",
            "需要掌握哪些编程语言?",
            "RAG相关经验是必须的吗?",
            "如何准备面试?"
        ]
        
        for i, query in enumerate(queries, 1):
            print(f"\n【查询 {i}】: {query}")
            print("-" * 70)
            
            # 检索相关文档
            results = rag.retrieve_with_scores(query)
            
            print(f"检索到 {len(results)} 个相关片段:\n")
            
            for j, (doc, score) in enumerate(results, 1):
                print(f"  [{j}] 相似度: {score:.4f}")
                content = doc.page_content.strip()
                # 显示前200个字符
                preview = content[:200] + "..." if len(content) > 200 else content
                print(f"      内容: {preview}")
                print()
        
        print("="*70)
        print("\n✅ 演示完成!")
        print("\n💡 提示:")
        print("   这只是展示了RAG的检索功能")
        print("   要使用完整的智能问答,需要:")
        print("   1. 安装所有依赖: pip install -r requirements.txt")
        print("   2. 配置OpenAI API Key在.env文件")
        print("   3. 运行完整版: python main.py")
        
    except Exception as e:
        print(f"\n❌ 错误: {e}")
        print("\n💡 请确保已安装依赖:")
        print("   pip install -r requirements.txt")
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(demo_retrieval())
