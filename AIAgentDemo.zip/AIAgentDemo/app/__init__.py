"""
上海大数据中心政务智能客服应用
Government Intelligent Customer Service Application
"""

__version__ = "1.0.0"
