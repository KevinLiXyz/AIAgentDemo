"""
聊天机器人核心模块
Chatbot Core Module with LangChain
"""

from typing import List, Dict
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain_openai import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.schema import Document

from app.config import (
    OPENAI_API_KEY,
    LLM_MODEL,
    TEMPERATURE,
    SYSTEM_PROMPT
)
from app.rag import RAGRetriever


class GovernmentChatbot:
    """政务智能客服机器人"""
    
    def __init__(self, rag_retriever: RAGRetriever):
        """
        初始化聊天机器人
        
        Args:
            rag_retriever: RAG检索器实例
        """
        self.rag_retriever = rag_retriever
        self.llm = None
        self.memory = None
        self.qa_chain = None
        
        self._initialize_llm()
        self._initialize_memory()
        self._initialize_chain()
    
    def _initialize_llm(self):
        """初始化大语言模型"""
        print(f"🤖 正在初始化LLM模型: {LLM_MODEL}")
        
        if not OPENAI_API_KEY:
            raise ValueError(
                "OpenAI API Key未设置! 请在.env文件中设置OPENAI_API_KEY"
            )
        
        self.llm = ChatOpenAI(
            model=LLM_MODEL,
            temperature=TEMPERATURE,
            openai_api_key=OPENAI_API_KEY
        )
        
        print("✅ LLM模型初始化完成")
    
    def _initialize_memory(self):
        """初始化对话记忆"""
        self.memory = ConversationBufferMemory(
            memory_key="chat_history",
            output_key="answer",
            return_messages=True
        )
        
        print("💭 对话记忆已初始化")
    
    def _initialize_chain(self):
        """初始化对话检索链"""
        print("🔗 正在构建对话检索链...")
        
        # 自定义问答提示词模板
        qa_template = f"""{SYSTEM_PROMPT}

基于以下检索到的上下文信息回答用户的问题:

{{context}}

用户问题: {{question}}

请给出准确、有帮助的回答:"""
        
        QA_PROMPT = PromptTemplate(
            template=qa_template,
            input_variables=["context", "question"]
        )
        
        # 创建对话检索链
        self.qa_chain = ConversationalRetrievalChain.from_llm(
            llm=self.llm,
            retriever=self.rag_retriever.retriever,
            memory=self.memory,
            return_source_documents=True,
            combine_docs_chain_kwargs={"prompt": QA_PROMPT},
            verbose=False
        )
        
        print("✅ 对话检索链构建完成\n")
    
    def chat(self, user_input: str, show_sources: bool = False) -> Dict:
        """
        处理用户输入并返回回答
        
        Args:
            user_input: 用户输入的问题
            show_sources: 是否显示来源文档
            
        Returns:
            包含回答和来源的字典
        """
        if not user_input.strip():
            return {
                "answer": "请输入您的问题。",
                "sources": []
            }
        
        # 调用对话链
        result = self.qa_chain.invoke({"question": user_input})
        
        answer = result.get("answer", "抱歉,我无法回答这个问题。")
        source_docs = result.get("source_documents", [])
        
        response = {
            "answer": answer,
            "sources": []
        }
        
        # 如果需要显示来源
        if show_sources and source_docs:
            for i, doc in enumerate(source_docs[:3], 1):
                response["sources"].append({
                    "index": i,
                    "content": doc.page_content[:200] + "..." if len(doc.page_content) > 200 else doc.page_content
                })
        
        return response
    
    def reset_conversation(self):
        """重置对话历史"""
        self.memory.clear()
        print("🔄 对话历史已清空")
    
    def get_chat_history(self) -> List[Dict[str, str]]:
        """
        获取对话历史
        
        Returns:
            对话历史列表
        """
        messages = self.memory.chat_memory.messages
        history = []
        
        for msg in messages:
            if hasattr(msg, 'type'):
                role = "用户" if msg.type == "human" else "助手"
                history.append({
                    "role": role,
                    "content": msg.content
                })
        
        return history
